import os
from flask import Flask, render_template
from utils.database import init_db, close_db
from routes.auth_routes import auth_bp
from routes.main_routes import main_bp
from routes.appointment_routes import appt_bp
from routes.health_routes import health_bp


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me-in-production")
    app.config["DATABASE"] = os.path.join(app.instance_path, "gramcare.db")
    os.makedirs(app.instance_path, exist_ok=True)

    app.teardown_appcontext(close_db)
    for bp in (auth_bp, main_bp, appt_bp, health_bp):
        app.register_blueprint(bp)

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="We couldn't find that page."), 404

    with app.app_context():
        init_db()
    return app


if __name__ == "__main__":
    create_app().run(debug=True)
