import re
from datetime import date, timedelta

DOCTORS = [
    ("Dr. Patil", "General physician"),
    ("Dr. Shaikh", "Women & child health"),
    ("Dr. Kulkarni", "Diabetes & blood pressure"),
]
SLOTS = ["09:00", "10:00", "11:00", "12:00", "16:00", "17:00"]

# Rule-based triage: red-flag words force "urgent"; common symptoms add up.
RED_FLAGS = {"chest pain", "breathless", "unconscious", "seizure", "heavy bleeding",
             "snake bite", "stroke", "can't breathe", "vomiting blood"}
COMMON = {"fever", "vomiting", "diarrhea", "headache", "cough", "rash",
          "stomach pain", "dizziness", "weakness", "body pain"}


def valid_phone(phone: str) -> bool:
    return bool(re.fullmatch(r"[6-9]\d{9}", phone))


def booking_dates(days: int = 7):
    today = date.today()
    return [(today + timedelta(days=i)).isoformat() for i in range(days)]


def triage(text: str):
    t = text.lower()
    if any(flag in t for flag in RED_FLAGS):
        return "urgent", "Go to the nearest hospital or call 108 now. Do not wait for an appointment."
    hits = [s for s in COMMON if s in t]
    if len(hits) >= 3:
        return "see-doctor", "Book a doctor visit today or tomorrow."
    if hits:
        return "monitor", "Rest, drink clean water and watch for 2 days. Book a visit if it gets worse."
    return "monitor", "No serious signs found. Add more detail about your symptoms for better guidance."
