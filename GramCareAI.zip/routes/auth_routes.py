from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from utils.database import get_db
from utils.helpers import valid_phone

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        phone = request.form["phone"].strip()
        village = request.form["village"].strip()
        password = request.form["password"]
        error = None
        if not (name and village):
            error = "Enter your name and village."
        elif not valid_phone(phone):
            error = "Enter a valid 10-digit mobile number."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        if not error:
            db = get_db()
            if db.execute("SELECT 1 FROM users WHERE phone=?", (phone,)).fetchone():
                error = "This mobile number is already registered. Log in instead."
            else:
                db.execute("INSERT INTO users(name,phone,village,password_hash) VALUES(?,?,?,?)",
                           (name, phone, village, generate_password_hash(password)))
                db.commit()
                flash("Account created. Log in to continue.", "success")
                return redirect(url_for("auth.login"))
        flash(error, "error")
    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        phone = request.form["phone"].strip()
        user = get_db().execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()
        if user and check_password_hash(user["password_hash"], request.form["password"]):
            session.clear()
            session["user_id"], session["user_name"] = user["id"], user["name"]
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("main.dashboard"))
        flash("Mobile number or password is incorrect.", "error")
    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.home"))
