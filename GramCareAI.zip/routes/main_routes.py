from flask import Blueprint, render_template, session
from utils.database import get_db
from utils.decorators import login_required

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def home():
    return render_template("index.html")


@main_bp.route("/dashboard")
@login_required
def dashboard():
    db, uid = get_db(), session["user_id"]
    upcoming = db.execute(
        "SELECT * FROM appointments WHERE user_id=? AND status='booked' AND date>=date('now') "
        "ORDER BY date, slot LIMIT 3", (uid,)).fetchall()
    checks = db.execute(
        "SELECT * FROM symptom_checks WHERE user_id=? ORDER BY id DESC LIMIT 3", (uid,)).fetchall()
    return render_template("dashboard.html", upcoming=upcoming, checks=checks)
