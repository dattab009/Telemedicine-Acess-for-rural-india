from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from utils.database import get_db
from utils.decorators import login_required
from utils.helpers import DOCTORS, SLOTS, booking_dates

appt_bp = Blueprint("appointments", __name__, url_prefix="/appointments")


@appt_bp.route("/")
@login_required
def list_appointments():
    rows = get_db().execute("SELECT * FROM appointments WHERE user_id=? ORDER BY date DESC, slot",
                            (session["user_id"],)).fetchall()
    return render_template("appointments.html", appointments=rows)


@appt_bp.route("/book", methods=["GET", "POST"])
@login_required
def book():
    dates = booking_dates()
    if request.method == "POST":
        doctor, day, slot = request.form.get("doctor"), request.form.get("date"), request.form.get("slot")
        reason = request.form.get("reason", "").strip()
        if doctor not in [d[0] for d in DOCTORS] or day not in dates or slot not in SLOTS:
            flash("Choose a doctor, date and time from the list.", "error")
        else:
            db = get_db()
            taken = db.execute("SELECT 1 FROM appointments WHERE doctor=? AND date=? AND slot=? "
                               "AND status='booked'", (doctor, day, slot)).fetchone()
            if taken:
                flash("That time is already booked. Pick another slot.", "error")
            else:
                db.execute("INSERT INTO appointments(user_id,doctor,date,slot,reason) VALUES(?,?,?,?,?)",
                           (session["user_id"], doctor, day, slot, reason))
                db.commit()
                flash(f"Appointment booked with {doctor} on {day} at {slot}.", "success")
                return redirect(url_for("appointments.list_appointments"))
    return render_template("book.html", doctors=DOCTORS, slots=SLOTS, dates=dates)


@appt_bp.route("/<int:appt_id>/cancel", methods=["POST"])
@login_required
def cancel(appt_id):
    db = get_db()
    db.execute("UPDATE appointments SET status='cancelled' WHERE id=? AND user_id=?",
               (appt_id, session["user_id"]))
    db.commit()
    flash("Appointment cancelled.", "info")
    return redirect(url_for("appointments.list_appointments"))
