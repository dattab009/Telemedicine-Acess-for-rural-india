from flask import Blueprint, render_template, request, session
from utils.database import get_db
from utils.decorators import login_required
from utils.helpers import triage

health_bp = Blueprint("health", __name__, url_prefix="/health")


@health_bp.route("/check", methods=["GET", "POST"])
@login_required
def symptom_check():
    result = None
    if request.method == "POST":
        text = request.form.get("symptoms", "").strip()
        if text:
            level, advice = triage(text)
            db = get_db()
            db.execute("INSERT INTO symptom_checks(user_id,symptoms,level) VALUES(?,?,?)",
                       (session["user_id"], text, level))
            db.commit()
            result = {"level": level, "advice": advice, "text": text}
    return render_template("symptom_check.html", result=result)
